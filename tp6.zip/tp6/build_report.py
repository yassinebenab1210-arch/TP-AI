#!/usr/bin/env python3
from __future__ import annotations

import html
import subprocess
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent
REPORT_HTML = ROOT / "rapport.html"
REPORT_PDF = ROOT / "rapport.pdf"
ASSETS = ROOT / "report_assets"
ASSETS_RESIZED = ROOT / "report_assets_resized"
SRC = ROOT / "src"
DATA = ROOT / "data"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def source_block(title: str, path: Path) -> str:
    content = html.escape(read_text(path))
    return f"""
    <section class="code-block">
      <h3>{html.escape(title)}</h3>
      <pre>{content}</pre>
    </section>
    """


def prepare_image_for_report(filename: str) -> str:
    src = ASSETS / filename
    if not src.exists():
        return f"report_assets/{filename}"

    ASSETS_RESIZED.mkdir(exist_ok=True)
    dst = ASSETS_RESIZED / filename

    with Image.open(src) as im:
        rgb = im.convert("RGB")
        rgb.thumbnail((860, 540), Image.Resampling.LANCZOS)
        rgb.save(dst, format="PNG", optimize=True)

    return f"report_assets_resized/{filename}"


def image_block(filename: str, caption: str) -> str:
    rel = prepare_image_for_report(filename)
    return f"""
    <figure class="capture-figure">
      <div class="capture-frame">
        <img src="{html.escape(rel)}" alt="{html.escape(caption)}">
      </div>
      <figcaption>{html.escape(caption)}</figcaption>
    </figure>
    """


def run_experiments() -> list[dict[str, str]]:
    out = subprocess.check_output(["java", "-cp", "out", "ExperimentRunner", "--csv"], cwd=ROOT, text=True)
    rows = []
    for line in out.strip().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split(",")
        if len(parts) == 3 and parts[2] == "NO_PATH":
            rows.append({
                "start": parts[0],
                "goal": parts[1],
                "ucs_cost": "N/A",
                "ucs_nodes": "N/A",
                "ucs_time": "N/A",
                "bf_cost": "N/A",
                "bf_nodes": "N/A",
                "bf_time": "N/A",
                "gap": "N/A",
            })
        elif len(parts) == 8:
            ucs_cost = int(parts[2])
            bf_cost = int(parts[5])
            gap = bf_cost - ucs_cost
            rows.append({
                "start": parts[0],
                "goal": parts[1],
                "ucs_cost": str(ucs_cost),
                "ucs_nodes": parts[3],
                "ucs_time": parts[4],
                "bf_cost": str(bf_cost),
                "bf_nodes": parts[6],
                "bf_time": parts[7],
                "gap": "Optimal" if gap == 0 else f"+{gap} km",
            })
    return rows


def run_all_algorithms(start: str, goal: str) -> list[dict[str, str]]:
    out = subprocess.check_output(
        ["java", "-cp", "out", "ExperimentRunner", "--compare-all", start, goal],
        cwd=ROOT,
        text=True,
    )

    criterion = {
        "BFS": "minimise les etapes",
        "DFS": "exploration en profondeur",
        "UCS": "minimise g(n)",
        "Best-First": "minimise h(n)",
    }

    rows = []
    for line in out.strip().splitlines():
        line = line.strip()
        if not line:
            continue

        parts = line.split(",")
        if len(parts) == 4 and parts[3] == "NO_PATH":
            algo = parts[0]
            rows.append({
                "algo": algo,
                "criterion": criterion.get(algo, "-"),
                "cost": "N/A",
                "nodes": "N/A",
                "time": "N/A",
                "path_len": "N/A",
            })
        elif len(parts) == 7:
            algo = parts[0]
            rows.append({
                "algo": algo,
                "criterion": criterion.get(algo, "-"),
                "cost": parts[3],
                "nodes": parts[4],
                "time": parts[5],
                "path_len": parts[6],
            })

    return rows


def build_html() -> str:
    experiments = run_experiments()
  all_algorithms = run_all_algorithms("Tunis", "Tozeur")

    experiment_rows = "\n".join(
        f"""
        <tr>
          <td>{html.escape(r['start'])}</td>
          <td>{html.escape(r['goal'])}</td>
          <td>{html.escape(r['ucs_cost'])}</td>
          <td>{html.escape(r['ucs_nodes'])}</td>
          <td>{html.escape(r['ucs_time'])}</td>
          <td>{html.escape(r['bf_cost'])}</td>
          <td>{html.escape(r['bf_nodes'])}</td>
          <td>{html.escape(r['bf_time'])}</td>
          <td>{html.escape(r['gap'])}</td>
        </tr>
        """
        for r in experiments
    )

    all_algorithm_rows = "\n".join(
        f"""
        <tr>
          <td>{html.escape(r['algo'])}</td>
          <td>{html.escape(r['criterion'])}</td>
          <td>{html.escape(r['cost'])}</td>
          <td>{html.escape(r['nodes'])}</td>
          <td>{html.escape(r['time'])}</td>
          <td>{html.escape(r['path_len'])}</td>
        </tr>
        """
        for r in all_algorithms
    )

    default_images = [
      ("capture_01_vue_globale.png", "Vue globale de la carte avec les villes principales"),
      ("capture_02_chemin_optimal.png", "Chemin optimal et chemin alternatif affichés"),
      ("capture_03_zoom_local.png", "Vue zoomée avec localités secondaires visibles"),
      ("capture_04_aleanatif.png", "Vue zoomée et comparaison d'itinéraires"),
      ("capture_05_interface_complete.png", "Interface complète (carte, panneau de contrôle et résultats)"),
      ("capture_06_double_chemin.png", "Visualisation claire du double chemin (optimal + alternatif)"),
      ("capture_07_bizerte_borj.png", "Scénario Bizerte → Borj El Khadhra"),
    ]

    extra_images = []
    if ASSETS.exists():
      known = {name for name, _ in default_images}
      for p in sorted(ASSETS.glob("*.png")):
        if p.name not in known:
          extra_images.append((p.name, p.stem.replace('_', ' ')))

    images = "".join(image_block(name, caption) for name, caption in (default_images + extra_images))

    code_files = [
        ("Application principale", SRC / "TunisiaMapApp.java"),
        ("Lecture des données", SRC / "DataLoader.java"),
        ("Graphe pondéré", SRC / "Graph.java"),
        ("Algorithme BFS", SRC / "BFS.java"),
        ("Algorithme DFS", SRC / "DFS.java"),
        ("Algorithme UCS", SRC / "UCS.java"),
        ("Algorithme Best-First", SRC / "BestFirst.java"),
        ("Arête du graphe", SRC / "Edge.java"),
        ("Nœud de recherche", SRC / "SearchNode.java"),
        ("Résultat de recherche", SRC / "SearchResult.java"),
        ("Données des villes", SRC / "CityData.java"),
        ("Données des lieux zoomés", SRC / "PlaceData.java"),
        ("Générateur de captures", SRC / "ReportCaptureGenerator.java"),
        ("Runner d'expériences", SRC / "ExperimentRunner.java"),
    ]

    code_blocks = "\n".join(source_block(title, path) for title, path in code_files)

    return f"""<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Compte rendu TP6 Best-First + UCS</title>
<style>
  @page {{ margin: 1.8cm; }}
  body {{ font-family: Arial, Helvetica, sans-serif; color: #1b1b1b; line-height: 1.45; }}
  h1, h2, h3 {{ color: #153b75; margin-bottom: 0.35rem; }}
  h1 {{ font-size: 24px; margin-top: 0; }}
  h2 {{ font-size: 18px; margin-top: 1.25rem; border-bottom: 2px solid #d7e2f2; padding-bottom: 0.2rem; }}
  h3 {{ font-size: 14px; margin-top: 1rem; }}
  .meta {{ color: #555; font-size: 12px; margin-bottom: 1rem; }}
  .box {{ background: #f7f9fc; border: 1px solid #dfe7f1; padding: 0.9rem 1rem; border-radius: 8px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 12px; }}
  th, td {{ border: 1px solid #ccd7e3; padding: 0.45rem 0.5rem; vertical-align: top; }}
  th {{ background: #eaf2fb; text-align: left; }}
  figure {{ margin: 1rem 0; }}
  .capture-figure {{ break-inside: avoid; page-break-inside: avoid; }}
  .capture-frame {{
    border: 1px solid #cfd9e6;
    border-radius: 8px;
    background: #f5f8fc;
    padding: 6px;
    width: 72%;
    margin: 0 auto;
    text-align: center;
  }}
  figure img {{
    width: 100%;
    max-height: 11.5cm;
    height: auto;
    object-fit: contain;
    display: block;
    border-radius: 4px;
  }}
  figcaption {{ font-size: 12px; color: #555; margin-top: 0.25rem; }}
  .code-block pre {{ white-space: pre-wrap; word-break: break-word; background: #f4f4f4; border: 1px solid #d6d6d6; padding: 0.75rem; border-radius: 6px; font-family: "DejaVu Sans Mono", Consolas, monospace; font-size: 9px; line-height: 1.3; }}
  .code-block {{ break-inside: avoid; }}
  ul {{ margin-top: 0.35rem; }}
</style>
</head>
<body>
  <h1>Compte rendu TP6 – Best-First Search (avec comparaison UCS)</h1>
  <div class="meta">Carte routière interactive de la Tunisie – GLSI 2 – S4 2025/2026</div>
  <div class="box">
    <strong>Étudiant :</strong> BEN SALAH Chahine<br>
    <strong>Enseignant :</strong> Mohamed Lassoued<br>
    <strong>Section :</strong> GLSI2<br>
    <strong>Matière :</strong> Fondements de l'IA
  </div>

  <div class="box">
    <strong>Objectif.</strong> Réaliser une application Java Swing qui modélise le réseau routier tunisien sous forme de graphe pondéré, guide la recherche avec une heuristique (Best-First), puis compare les résultats avec UCS (coût réel g(n)).
  </div>

  <h2>2. Modélisation (réponses aux questions d’analyse)</h2>
  <h3>2.1 Partie A — Formalisation</h3>
  <ul>
    <li><strong>État initial :</strong> la ville de départ choisie par l’utilisateur (cas de base : Tunis).</li>
    <li><strong>État but :</strong> la ville d’arrivée choisie par l’utilisateur (cas de base : Tozeur).</li>
    <li><strong>États intermédiaires :</strong> toutes les autres localités du graphe.</li>
    <li><strong>Transition :</strong> déplacement entre deux localités reliées par une arête.</li>
  </ul>
  <p><strong>Différence des mesures :</strong> UCS minimise g(n) (coût déjà parcouru), Best-First minimise h(n) (estimation au but). Best-First peut explorer moins de nœuds, mais sans garantie d’optimalité.</p>
  <p><strong>Pourquoi graphe pondéré :</strong> les routes n’ont pas le même coût en km ; l’optimalité doit porter sur la somme des coûts et non sur le nombre d’arêtes.</p>

  <h3>2.2 Partie B — Structure de graphe</h3>
  <p><strong>Pourquoi une liste d’adjacence ?</strong> Elle est plus compacte pour un graphe peu dense et plus efficace pour itérer les voisins.</p>
  <p><strong>Différence avec une matrice d’adjacence :</strong> la matrice coûte O(V²) en mémoire même si peu d’arêtes existent, alors que la liste coûte O(V+E).</p>

  <h3>2.3 Partie C — UCS et Best-First</h3>
  <p><strong>Pourquoi stocker le parent dans Node ?</strong> pour reconstruire le chemin final en remontant du but vers la racine.</p>
  <p><strong>Pourquoi développer le nœud de priorité minimale ?</strong> UCS choisit le plus petit g(n) (optimalité garantie), tandis que Best-First choisit le plus petit h(n) (rapidité potentielle).</p>

  <h3>2.4 Partie D — Reconstruction du chemin</h3>
  <p><strong>Pourquoi ne pas afficher le chemin directement pendant la recherche ?</strong> avant d’extraire l’état but, le chemin courant peut encore être remplacé par une meilleure alternative.</p>

  <h2>3. Expérimentation et Complexité</h2>
  <p>Les expérimentations comparent UCS et Best-First sur plusieurs routes représentatives. Les résultats confirment le compromis classique : Best-First explore souvent beaucoup moins de nœuds, mais le coût final peut être supérieur à UCS.</p>
  <table>
    <thead>
      <tr>
        <th>Départ</th><th>Arrivée</th><th>UCS coût (km)</th><th>UCS nœuds</th><th>UCS ms</th><th>Best-First coût (km)</th><th>Best-First nœuds</th><th>Best-First ms</th><th>Écart BF vs UCS</th>
      </tr>
    </thead>
    <tbody>
      {experiment_rows}
    </tbody>
  </table>
  <p><strong>Lecture des résultats :</strong> UCS fournit systématiquement la meilleure solution en coût, alors que Best-First suit le chemin estimé le plus prometteur selon l’heuristique.</p>
  <p><strong>Cas guidés du TP :</strong> le cas de base Tunis→Tozeur est évalué, ainsi que des cas supplémentaires pour observer l’impact de la qualité de l’heuristique sur l’ordre d’exploration et la qualité du chemin.</p>
  <p><strong>Complexité :</strong> O((V+E) log V) avec file de priorité.</p>

  <h3>3.1 Tableau comparatif BFS / DFS / UCS / Best-First (cas Tunis→Tozeur)</h3>
  <table>
    <thead>
      <tr>
        <th>Algorithme</th><th>Critère de sélection</th><th>Coût obtenu (km)</th><th>Nœuds explorés</th><th>Temps (ms)</th><th>Taille du chemin</th>
      </tr>
    </thead>
    <tbody>
      {all_algorithm_rows}
    </tbody>
  </table>

  <h2>4. Discussion critique</h2>
  <ul>
    <li><strong>Pourquoi Best-First est rapide :</strong> il réduit souvent l’espace exploré en ciblant les nœuds proches du but selon h(n).</li>
    <li><strong>Pourquoi UCS reste la référence d’optimalité :</strong> il ordonne strictement l’exploration par g(n).</li>
    <li><strong>Limite de Best-First :</strong> une heuristique trompeuse peut conduire à un chemin plus coûteux.</li>
    <li><strong>Piste d’amélioration :</strong> A* combine g(n)+h(n) pour équilibrer rapidité et qualité de solution.</li>
  </ul>

  <h2>5. Captures d’écran d’exécution</h2>
  {images}

  <h2>6. Conclusion</h2>
  <p>Le projet couvre bien TP5 et TP6 : modélisation du graphe pondéré, implémentation de UCS et Best-First, comparaison expérimentale, visualisation interactive et génération de captures/rapport automatisée.</p>

  <h2>7. Codes sources</h2>
  <p>Le code ci-dessous inclut l’application principale, le chargement des données, le graphe, les algorithmes UCS et Best-First, ainsi que les utilitaires d’expérimentation et de capture.</p>
  {code_blocks}
</body>
</html>"""


def main() -> None:
    html_text = build_html()
    REPORT_HTML.write_text(html_text, encoding="utf-8")
    print(f"Wrote {REPORT_HTML}")

    subprocess.run([
        "soffice", "--headless", "--convert-to", "pdf", "--outdir", str(ROOT), str(REPORT_HTML)
    ], check=True, cwd=ROOT)
    generated = ROOT / "rapport.pdf"
    if generated.exists():
        generated.rename(REPORT_PDF)
        print(f"Wrote {REPORT_PDF}")


if __name__ == "__main__":
    main()
