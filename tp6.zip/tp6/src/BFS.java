import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class BFS {
    private BFS() {
    }

    public static SearchResult run(Graph graph, String start, String goal) {
        if (start == null || goal == null || !graph.hasCity(start) || !graph.hasCity(goal)) {
            return null;
        }

        Queue<SearchNode> open = new ArrayDeque<>();
        Set<String> discovered = new HashSet<>();
        List<String> explorationOrder = new ArrayList<>();
        int nodesExplored = 0;

        long t0 = System.currentTimeMillis();
        open.add(new SearchNode(start, null, 0));
        discovered.add(start);

        while (!open.isEmpty()) {
            SearchNode current = open.poll();
            nodesExplored++;
            explorationOrder.add(current.city);

            if (current.city.equals(goal)) {
                LinkedList<String> path = new LinkedList<>();
                for (SearchNode n = current; n != null; n = n.parent) {
                    path.addFirst(n.city);
                }
                long elapsed = System.currentTimeMillis() - t0;
                return new SearchResult(path, current.gCost, nodesExplored, elapsed, explorationOrder);
            }

            for (Edge edge : graph.neighbors(current.city)) {
                if (discovered.contains(edge.dest)) {
                    continue;
                }
                discovered.add(edge.dest);
                open.add(new SearchNode(edge.dest, current, current.gCost + edge.cost));
            }
        }

        return null;
    }
}
