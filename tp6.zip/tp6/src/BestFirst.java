import java.util.*;

public class BestFirst {
    private BestFirst() {}

    public static SearchResult run(Graph graph, Map<String, CityData> cityMap, String start, String goal) {
        return run(graph, cityMap, start, goal, null);
    }

    public static SearchResult run(
        Graph graph,
        Map<String, CityData> cityMap,
        String start,
        String goal,
        Map<String, Integer> heuristicOverrides
    ) {
        PriorityQueue<SearchNode> open = createPriorityQueue(goal, cityMap, heuristicOverrides);
        Set<String> visited = new HashSet<>();
        List<String> explorationOrder = new ArrayList<>();
        int nodesExplored = 0;

        long t0 = System.currentTimeMillis();
        open.add(new SearchNode(start, null, 0));

        while (!open.isEmpty()) {
            SearchNode current = open.poll();
            if (visited.contains(current.city)) continue;

            visited.add(current.city);
            nodesExplored++;
            explorationOrder.add(current.city);

            if (current.city.equals(goal)) {
                return buildSearchResult(current, nodesExplored, t0, explorationOrder);
            }

            processNeighbors(graph, open, visited, current);
        }

        return null;
    }

    private static void processNeighbors(Graph graph, PriorityQueue<SearchNode> open, Set<String> visited, SearchNode current) {
        for (Edge edge : graph.neighbors(current.city)) {
            if (!visited.contains(edge.dest)) {
                open.add(new SearchNode(edge.dest, current, current.gCost + edge.cost));
            }
        }
    }

    private static SearchResult buildSearchResult(SearchNode current, int nodesExplored, long startTime, List<String> explorationOrder) {
        LinkedList<String> path = new LinkedList<>();
        for (SearchNode n = current; n != null; n = n.parent) {
            path.addFirst(n.city);
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        return new SearchResult(path, current.gCost, nodesExplored, elapsedTime, explorationOrder);
    }

    private static PriorityQueue<SearchNode> createPriorityQueue(String goal, Map<String, CityData> cityMap, Map<String, Integer> heuristicOverrides) {
        return new PriorityQueue<>(
            Comparator
                .comparingInt((SearchNode n) -> heuristic(n.city, goal, cityMap, heuristicOverrides))
                .thenComparingInt(n -> n.gCost)
        );
    }

    public static Map<String, Integer> buildHeuristicToGoal(Map<String, CityData> cityMap, String goal) {
        Map<String, Integer> h = new LinkedHashMap<>();
        for (String city : cityMap.keySet()) {
            h.put(city, heuristic(city, goal, cityMap, null));
        }
        return h;
    }

    private static int heuristic(String city, String goal, Map<String, CityData> cityMap, Map<String, Integer> overrides) {
        if (city.equals(goal)) return 0;
        if (overrides != null && overrides.containsKey(city)) return Math.max(0, overrides.get(city));
        CityData a = cityMap.get(city), b = cityMap.get(goal);
        if (a == null || b == null) return 0;
        return (int) Math.round(haversineKm(a.lat, a.lon, b.lat, b.lon));
    }

    private static double haversineKm(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371.0;
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
            + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
            * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return r * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }
}