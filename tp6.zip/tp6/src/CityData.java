public class CityData {
    public final String id;
    public final String display;
    public final double lat;
    public final double lon;

    public int px;
    public int py;

    public CityData(String id, double lat, double lon) {
        this.id = id;
        this.display = id.replace('_', ' ');
        this.lat = lat;
        this.lon = lon;
    }
}
