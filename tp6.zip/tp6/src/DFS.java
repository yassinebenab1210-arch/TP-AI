import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class DFS {
    private DFS() {}

    public static SearchResult run(Graph graph, String start, String goal) {
        if (isInvalidInput(graph, start, goal)) {
            return null;
        }

        Deque<SearchNode> stack = new ArrayDeque<>();
        Set<String> discovered = new HashSet<>();
        List<String> explorationOrder = new ArrayList<>();
        int nodesExplored = 0;

        long t0 = System.currentTimeMillis();
        initializeSearch(stack, discovered, start);

        while (!stack.isEmpty()) {
            SearchNode current = stack.pop();
            nodesExplored++;
            explorationOrder.add(current.city);

            if (current.city.equals(goal)) {
                return buildSearchResult(current, nodesExplored, t0, explorationOrder);
            }

            exploreNeighbors(graph, stack, discovered, current);
        }

        return null;
    }

    private static boolean isInvalidInput(Graph graph, String start, String goal) {
        return start == null || goal == null || !graph.hasCity(start) || !graph.hasCity(goal);
    }

    private static void initializeSearch(Deque<SearchNode> stack, Set<String> discovered, String start) {
        stack.push(new SearchNode(start, null, 0));
        discovered.add(start);
    }

    private static void exploreNeighbors(Graph graph, Deque<SearchNode> stack, Set<String> discovered, SearchNode current) {
        List<Edge> neighbors = graph.neighbors(current.city);
        for (int i = neighbors.size() - 1; i >= 0; i--) {
            Edge edge = neighbors.get(i);
            if (!discovered.contains(edge.dest)) {
                discovered.add(edge.dest);
                stack.push(new SearchNode(edge.dest, current, current.gCost + edge.cost));
            }
        }
    }

    private static SearchResult buildSearchResult(SearchNode current, int nodesExplored, long startTime, List<String> explorationOrder) {
        LinkedList<String> path = new LinkedList<>();
        for (SearchNode n = current; n != null; n = n.parent) {
            path.addFirst(n.city);
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        return new SearchResult(path, current.gCost, nodesExplored, elapsedTime, explorationOrder);
    }
}