import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

public class DataLoader {
    private DataLoader() {
    }

    /**
     * Loads cities and distances only (places_zoom.csv removed).
     */
    public static void loadAll(Map<String, CityData> cityMap, Graph graph)
        throws IOException {
        String dataDir = resolveDataDir();
        loadCities(dataDir + File.separator + "cities.csv", cityMap);
        loadDistances(dataDir + File.separator + "distances.csv", graph);
    }

    private static String resolveDataDir() {
        for (String candidate : new String[]{"data", "../data", "TunisiaUCS/data"}) {
            if (new File(candidate + "/cities.csv").exists()) {
                return candidate;
            }
        }
        return "data";
    }

    private static void loadCities(String path, Map<String, CityData> cityMap) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String id  = parts[0].trim();
                    double lat = Double.parseDouble(parts[1].trim());
                    double lon = Double.parseDouble(parts[2].trim());
                    cityMap.put(id, new CityData(id, lat, lon));
                }
            }
        }
    }

    private static void loadDistances(String path, Graph graph) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine(); // skip header
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length >= 3) {
                    String a  = parts[0].trim();
                    String b  = parts[1].trim();
                    int dist  = Integer.parseInt(parts[2].trim());
                    graph.addEdge(a, b, dist);
                }
            }
        }
    }
}
