public class Edge {
    public final String dest;
    public final int cost;

    public Edge(String dest, int cost) {
        this.dest = dest;
        this.cost = cost;
    }
}
