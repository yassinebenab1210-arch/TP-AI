import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ExperimentRunner {

    private static final class Scenario {
        final String start, goal;

        Scenario(String start, String goal) {
            this.start = start;
            this.goal = goal;
        }
    }

    private static final List<Scenario> SCENARIOS = List.of(
        new Scenario("Tunis", "Tozeur"),
        new Scenario("Tunis", "Sfax"),
        new Scenario("Nabeul", "Gafsa"),
        new Scenario("Bizerte", "Borj_El_Khadhra"),
        new Scenario("Djerba_Houmt_Souk", "Tozeur")
    );

    public static void main(String[] args) throws Exception {
        Map<String, CityData> cityMap = new LinkedHashMap<>();
        Graph graph = new Graph();
        DataLoader.loadAll(cityMap, graph);

        if (args.length > 0) {
            if ("--csv".equals(args[0])) {
                runCsv(graph, cityMap);
                return;
            } else if ("--compare-all".equals(args[0])) {
                runCompareAll(graph, cityMap, args);
                return;
            }
        }

        String start = "Tunis", goal = "Tozeur";
        System.out.println("=== Best-First Search — Carte de Tunisie ===");

        runScenario(graph, cityMap, start, goal);
    }

    private static void runScenario(Graph graph, Map<String, CityData> cityMap, String start, String goal) {
        SearchResult base = runBF(graph, cityMap, start, goal, null, "CAS 1 — Tunis -> Tozeur (base)");

        Map<String, Integer> bad = createBadHeuristics();
        runBF(graph, cityMap, start, goal, bad, "CAS 2 — Mauvaise heuristique");

        System.out.println("\nCAS 3 — Comparaison BFS / DFS / UCS / Best-First");
        compareSearchAlgorithms(graph, cityMap, start, goal);  // Pass cityMap here

        Map<String, Integer> mis = createMisleadingHeuristics();
        runBF(graph, cityMap, start, goal, mis, "CAS 4 — Heuristique trompeuse");

        System.out.println("\nRésumé multi-scénarios");
        for (Scenario s : SCENARIOS) {
            runMultipleScenarios(graph, cityMap, s);
        }
    }

    private static Map<String, Integer> createBadHeuristics() {
        Map<String, Integer> bad = new LinkedHashMap<>();
        bad.put("Le_Kef", 5000);
        bad.put("Kasserine", 5000);
        bad.put("Sfax", 1);
        bad.put("Gabes", 1);
        return bad;
    }

    private static Map<String, Integer> createMisleadingHeuristics() {
        Map<String, Integer> mis = new LinkedHashMap<>();
        mis.put("Le_Kef", 0);
        mis.put("Kasserine", 0);
        mis.put("Gafsa", 1200);
        return mis;
    }

    private static void compareSearchAlgorithms(Graph graph, Map<String, CityData> cityMap, String start, String goal) {
        SearchResult bfs = BFS.run(graph, start, goal);
        SearchResult dfs = DFS.run(graph, start, goal);
        SearchResult ucs = UCS.run(graph, start, goal);
        SearchResult bf = BestFirst.run(graph, cityMap, start, goal);  // Pass cityMap here

        printAll(bfs, dfs, ucs, bf);
    }

    private static void runMultipleScenarios(Graph graph, Map<String, CityData> cityMap, Scenario s) {
        SearchResult r1 = BFS.run(graph, s.start, s.goal);
        SearchResult r2 = DFS.run(graph, s.start, s.goal);
        SearchResult r3 = UCS.run(graph, s.start, s.goal);
        SearchResult r4 = BestFirst.run(graph, cityMap, s.start, s.goal);

        if (r1 == null || r2 == null || r3 == null || r4 == null) {
            System.out.println("- " + s.start + " -> " + s.goal + " : NO_PATH");
            return;
        }

        System.out.println("- " + s.start + " -> " + s.goal
            + " | BFS=" + r1.totalCost + "km/" + r1.nodesExplored
            + " | DFS=" + r2.totalCost + "km/" + r2.nodesExplored
            + " | UCS=" + r3.totalCost + "km/" + r3.nodesExplored
            + " | BF=" + r4.totalCost + "km/" + r4.nodesExplored
            + " | écart=" + (r4.totalCost - r3.totalCost) + " km");
    }

    private static void runCsv(Graph graph, Map<String, CityData> cityMap) {
        for (Scenario s : SCENARIOS) {
            SearchResult ucs = UCS.run(graph, s.start, s.goal);
            SearchResult bf = BestFirst.run(graph, cityMap, s.start, s.goal);

            if (ucs == null || bf == null) {
                System.out.println(s.start + "," + s.goal + ",NO_PATH");
                continue;
            }
            System.out.println(s.start + "," + s.goal + ","
                + ucs.totalCost + "," + ucs.nodesExplored + "," + ucs.timeMs + ","
                + bf.totalCost + "," + bf.nodesExplored + "," + bf.timeMs);
        }
    }

    private static void runCompareAll(Graph graph, Map<String, CityData> cityMap, String[] args) {
        String s = args.length > 1 ? args[1] : "Tunis";
        String g = args.length > 2 ? args[2] : "Tozeur";

        emit("BFS", s, g, BFS.run(graph, s, g));
        emit("DFS", s, g, DFS.run(graph, s, g));
        emit("UCS", s, g, UCS.run(graph, s, g));
        emit("Best-First", s, g, BestFirst.run(graph, cityMap, s, g));
    }

    private static void emit(String algo, String s, String g, SearchResult r) {
        if (r == null) {
            System.out.println(algo + "," + s + "," + g + ",NO_PATH");
            return;
        }
        System.out.println(algo + "," + s + "," + g + "," + r.totalCost + "," + r.nodesExplored + "," + r.timeMs + "," + r.path.size());
    }

    private static SearchResult runBF(Graph graph, Map<String, CityData> cityMap,
                                      String s, String g, Map<String, Integer> overrides, String title) {
        System.out.println("\n" + title);
        SearchResult r = BestFirst.run(graph, cityMap, s, g, overrides);
        if (r == null) {
            System.out.println("NO_PATH");
            return null;
        }
        System.out.println("Chemin  : " + String.join(" -> ", r.path));
        System.out.println("Coût    : " + r.totalCost + " km");
        System.out.println("Nœuds   : " + r.nodesExplored);
        System.out.println("Temps   : " + r.timeMs + " ms");
        return r;
    }

    private static void printAll(SearchResult bfs, SearchResult dfs, SearchResult ucs, SearchResult bf) {
        if (bfs == null || dfs == null || ucs == null || bf == null) {
            System.out.println("Résultat manquant.");
            return;
        }
        System.out.println("BFS       | " + bfs.totalCost + " km, " + bfs.nodesExplored + " nœuds");
        System.out.println("DFS       | " + dfs.totalCost + " km, " + dfs.nodesExplored + " nœuds");
        System.out.println("UCS       | " + ucs.totalCost + " km, " + ucs.nodesExplored + " nœuds");
        System.out.println("BestFirst | " + bf.totalCost + " km, " + bf.nodesExplored + " nœuds");
    }
}