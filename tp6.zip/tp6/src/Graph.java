import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class Graph {
    public final Map<String, List<Edge>> adj = new LinkedHashMap<>();

    public void addEdge(String a, String b, int cost) {
        if (a.equals(b)) {
            return;
        }
        adj.computeIfAbsent(a, k -> new ArrayList<>());
        adj.computeIfAbsent(b, k -> new ArrayList<>());

        if (!hasEdge(a, b)) {
            adj.get(a).add(new Edge(b, cost));
            adj.get(b).add(new Edge(a, cost));
        }
    }

    public List<Edge> neighbors(String city) {
        return adj.getOrDefault(city, Collections.emptyList());
    }

    public boolean hasCity(String id) {
        return adj.containsKey(id);
    }

    public boolean hasEdge(String a, String b) {
        for (Edge e : adj.getOrDefault(a, Collections.emptyList())) {
            if (e.dest.equals(b)) {
                return true;
            }
        }
        return false;
    }
}
