public class PlaceData {
    public final String id;
    public final String display;
    public final double lat;
    public final double lon;
    public final int population;

    public int px;
    public int py;

    public PlaceData(String id, double lat, double lon, int population) {
        this.id = id;
        this.display = id.replace('_', ' ');
        this.lat = lat;
        this.lon = lon;
        this.population = population;
    }
}
