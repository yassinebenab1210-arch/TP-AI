public class SearchNode implements Comparable<SearchNode> {
    public final String city;
    public final SearchNode parent;
    public final int gCost;

    public SearchNode(String city, SearchNode parent, int gCost) {
        this.city = city;
        this.parent = parent;
        this.gCost = gCost;
    }

    @Override
    public int compareTo(SearchNode other) {
        return Integer.compare(gCost, other.gCost);
    }
}
