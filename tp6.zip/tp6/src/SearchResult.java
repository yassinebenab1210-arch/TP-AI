import java.util.List;
import java.util.Collections;

public class SearchResult {
    public final List<String> path;
    public final int totalCost;
    public final int nodesExplored;
    public final long timeMs;
    public final List<String> explorationOrder;

    public SearchResult(List<String> path, int totalCost, int nodesExplored, long timeMs) {
        this(path, totalCost, nodesExplored, timeMs, Collections.emptyList());
    }

    public SearchResult(List<String> path, int totalCost, int nodesExplored, long timeMs, List<String> explorationOrder) {
        this.path = path;
        this.totalCost = totalCost;
        this.nodesExplored = nodesExplored;
        this.timeMs = timeMs;
        this.explorationOrder = explorationOrder;
    }
}
