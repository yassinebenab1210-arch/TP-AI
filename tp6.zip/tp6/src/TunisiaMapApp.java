import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

import java.util.*;


public class TunisiaMapApp extends JFrame {
    
    private static final Color MAP_BG = new Color(20, 20, 20); // Darker background
    private static final Color MAP_OCEAN = new Color(10, 20, 40); // Blueish for ocean
    private static final Color MAP_LAND = new Color(50, 70, 40); // Greenish for land
    private static final Color MAP_BORDER = new Color(40, 60, 30); // Lighter border
    private static final Color ACCENT_G = new Color(255, 200, 0); // Bright yellow for accents
    
    private Map<String, CityData> cityMap = new LinkedHashMap<>();
    private Graph graph = new Graph();
    
    private String startCity, goalCity;
    private SearchResult lastResult;
    
    private MapCanvas canvas;
    
    public TunisiaMapApp() {
        super("New Tunisia Route Finder");
        loadData();
        buildUI();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1440, 900);
        setMinimumSize(new Dimension(1000, 680));
        setLocationRelativeTo(null);
    }
    
    private void loadData() {
        try { 
            DataLoader.loadAll(cityMap, graph);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Cannot load data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
    }
    
    private void buildUI() {
        setBackground(MAP_BG);
        Container ct = getContentPane();
        ct.setLayout(new BorderLayout());
        
        canvas = new MapCanvas();
        ct.add(canvas, BorderLayout.CENTER);
        
        JPanel controlPanel = buildControlPanel();
        ct.add(controlPanel, BorderLayout.WEST);
    }
    
    private JPanel buildControlPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(40, 40, 40));
        
        JLabel titleLabel = new JLabel("Tunisia Route Finder");
        titleLabel.setForeground(ACCENT_G);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(titleLabel);
        
        // Start City combo box
        JComboBox<String> startCombo = new JComboBox<>();
        startCombo.addItem("Tunis");
        startCombo.addItem("Sfax");
        panel.add(startCombo);
        
        // Goal City combo box
        JComboBox<String> goalCombo = new JComboBox<>();
        goalCombo.addItem("Tozeur");
        goalCombo.addItem("Bizerte");
        panel.add(goalCombo);
        
        // Search Button
        JButton searchButton = new JButton("Search Path");
        searchButton.setBackground(ACCENT_G);
        searchButton.setForeground(Color.WHITE);
        panel.add(searchButton);
        
        return panel;
    }
    
    private class MapCanvas extends JPanel {
        
        MapCanvas() {
            setBackground(MAP_BG);
            setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
            
            addMouseListener(new MouseAdapter() {
                @Override public void mousePressed(MouseEvent e) { onMapClick(e); }
            });
            
            addMouseMotionListener(new MouseMotionAdapter() {
                @Override public void mouseMoved(MouseEvent e) { onHover(e.getX(), e.getY()); }
            });
        }
        
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Paint the map elements here (Ocean, Land, Roads, Paths, etc.)
            paintOcean(g2d);
            paintLand(g2d);
        }
        
        private void paintOcean(Graphics2D g) {
            g.setColor(MAP_OCEAN);
            g.fillRect(0, 0, getWidth(), getHeight());
        }
        
        private void paintLand(Graphics2D g) {
            g.setColor(MAP_LAND);
            g.fillRect(50, 50, 200, 200); // Example area to represent land
        }
        
        private void onMapClick(MouseEvent e) {
            // Add logic for map click events
        }
        
        private void onHover(int mx, int my) {
            // Add logic for hovering over cities on the map
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new TunisiaMapApp().setVisible(true));
    }
}

