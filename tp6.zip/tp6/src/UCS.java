import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Set;

public class UCS {
    private UCS() {
    }

    public static SearchResult run(Graph graph, String start, String goal) {
        return run(graph, start, goal, null);
    }

    public static SearchResult run(Graph graph, String start, String goal, Set<String> blockedEdges) {
        PriorityQueue<SearchNode> open = createPriorityQueue();
        Set<String> visited = new HashSet<>();
        List<String> explorationOrder = new ArrayList<>();
        int nodesExplored = 0;

        long t0 = System.currentTimeMillis();
        open.add(new SearchNode(start, null, 0));

        while (!open.isEmpty()) {
            SearchNode current = open.poll();
            if (visited.contains(current.city)) continue;

            visited.add(current.city);
            nodesExplored++;
            explorationOrder.add(current.city);

            if (current.city.equals(goal)) {
                return buildSearchResult(current, nodesExplored, t0, explorationOrder);
            }

            exploreNeighbors(graph, open, visited, current, blockedEdges);
        }

        return null;
    }

    private static PriorityQueue<SearchNode> createPriorityQueue() {
        return new PriorityQueue<>();
    }

    private static void exploreNeighbors(Graph graph, PriorityQueue<SearchNode> open, Set<String> visited,
                                         SearchNode current, Set<String> blockedEdges) {
        for (Edge edge : graph.neighbors(current.city)) {
            if (isBlocked(current.city, edge.dest, blockedEdges)) continue;
            if (!visited.contains(edge.dest)) {
                open.add(new SearchNode(edge.dest, current, current.gCost + edge.cost));
            }
        }
    }

    private static boolean isBlocked(String from, String to, Set<String> blockedEdges) {
        return blockedEdges != null && blockedEdges.contains(edgeKey(from, to));
    }

    private static String edgeKey(String a, String b) {
        return a.compareTo(b) < 0 ? a + "\0" + b : b + "\0" + a;
    }

    private static SearchResult buildSearchResult(SearchNode current, int nodesExplored, long startTime, List<String> explorationOrder) {
        LinkedList<String> path = new LinkedList<>();
        for (SearchNode n = current; n != null; n = n.parent) {
            path.addFirst(n.city);
        }

        long elapsedTime = System.currentTimeMillis() - startTime;
        return new SearchResult(path, current.gCost, nodesExplored, elapsedTime, explorationOrder);
    }

    public static SearchResult findSecondBest(Graph graph, String start, String goal, List<String> primaryPath) {
        if (primaryPath == null || primaryPath.size() < 2) return null;

        SearchResult bestAlternative = null;
        Set<String> blocked = new HashSet<>();

        for (int i = 0; i < primaryPath.size() - 1; i++) {
            blocked.clear();
            blocked.add(edgeKey(primaryPath.get(i), primaryPath.get(i + 1)));

            SearchResult candidate = run(graph, start, goal, blocked);
            if (candidate == null || candidate.path.equals(primaryPath)) continue;

            if (bestAlternative == null || candidate.totalCost < bestAlternative.totalCost) {
                bestAlternative = candidate;
            }
        }

        return bestAlternative;
    }
}